const express = require('express');
const cors = require('cors');
const axios = require('axios');
const cheerio = require('cheerio');

const app = express();
const PORT = 3000;

app.use(cors());
app.use(express.json());

app.get('/translate', async (req, res) => {
    const word = req.query.word;
    if (!word) {
        return res.status(400).json({ error: 'Missing word parameter' });
    }

    try {
        console.log(`Fetching translation for: ${word}`);
        // 使用 Bing 词典获取高质量英汉翻译
        const url = `https://cn.bing.com/dict/search?q=${encodeURIComponent(word)}`;
        const { data } = await axios.get(url, {
            headers: {
                'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36'
            }
        });

        const $ = cheerio.load(data);
        const result = {
            word: word,
            phonetic: '',
            meanings: []
        };

        // 1. 获取音标
        // Bing 结构通常是: .hd_prUS (美) .hd_pr (英)
        let usPhonetic = $('.hd_prUS').text().trim();
        let ukPhonetic = $('.hd_pr').not('.hd_prUS').text().trim();
        
        // 清理一下
        if (usPhonetic.startsWith('美')) usPhonetic = usPhonetic.replace('美', '').trim();
        if (ukPhonetic.startsWith('英')) ukPhonetic = ukPhonetic.replace('英', '').trim();

        result.phonetic = usPhonetic || ukPhonetic || '';

        // 2. 获取释义
        // 核心释义在 .qdef ul li
        $('.qdef ul li').each((i, el) => {
            const pos = $(el).find('.pos').text().trim();
            const def = $(el).find('.def').text().trim();
            if (def) {
                // 有时候 pos 是空的，但也需要
                result.meanings.push({ pos: pos || '常用', def });
            }
        });
        
        // 如果没有 .qdef，尝试 .wd_div (Web Definition / Wiki)
        if (result.meanings.length === 0) {
             $('.wd_div').each((i, el) => {
                 const pos = $(el).find('.wd_t').text().trim();
                 const def = $(el).find('.wd_d').text().trim();
                  if (def) {
                    result.meanings.push({ pos: pos || '网络', def });
                }
             });
        }

        // 3. 如果还是没有，尝试 .p1-10 (Sample sentences area might have definitions?) No, usually .df_div
        if (result.meanings.length === 0) {
             // 简单的网络释义
             $('.df_div .df_row').each((i, el) => {
                 const def = $(el).find('.df_L').text().trim();
                 if (def) {
                     result.meanings.push({ pos: '网络', def });
                 }
             });
        }

        if (result.meanings.length === 0) {
            console.log('No definitions found on Bing.');
            return res.status(404).json({ error: 'No definitions found' });
        }

        res.json(result);

    } catch (error) {
        console.error('Translation error:', error.message);
        res.status(500).json({ error: 'Failed to fetch translation' });
    }
});

app.listen(PORT, () => {
    console.log(`Backend server running at http://localhost:${PORT}`);
});
